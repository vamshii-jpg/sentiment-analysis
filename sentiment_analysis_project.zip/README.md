# 🧠 Sentiment Analysis using Naive Bayes

This is a beginner-level machine learning project that uses **Naive Bayes** to analyze sentiment in text data.

## 🔧 Technologies Used
- Python
- pandas
- scikit-learn

## 🚀 How to Run

1. Clone this repository:
```bash
git clone https://github.com/your-username/sentiment-analysis.git
cd sentiment-analysis
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the code:
```bash
python sentiment_analysis.py
```

## 📌 Output Example

```
Accuracy: 1.0  
Sentiment: positive
```

## 👤 Author

Kota Vamshi Krishna
